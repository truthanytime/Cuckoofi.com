--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "cuckoofi-travel-dev";
--
-- Name: cuckoofi-travel-dev; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "cuckoofi-travel-dev" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "cuckoofi-travel-dev" OWNER TO postgres;

\connect -reuse-previous=on "dbname='cuckoofi-travel-dev'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    date_created timestamp with time zone NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    date_deleted timestamp with time zone,
    is_deleted integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: COLUMN roles.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.roles.id IS 'Id of role';


--
-- Name: COLUMN roles.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.roles.name IS 'The name of role';


--
-- Name: COLUMN roles.is_deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.roles.is_deleted IS 'Represent whether this user was deleted(1) or not(0)';


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.roles ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    user_id character varying(36) NOT NULL,
    role_id integer NOT NULL,
    date_created timestamp with time zone NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    date_deleted timestamp with time zone,
    is_deleted integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: COLUMN user_roles.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_roles.id IS 'Primary key for user_roles table';


--
-- Name: COLUMN user_roles.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_roles.user_id IS 'Foreign key referencing the users table (user id)';


--
-- Name: COLUMN user_roles.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_roles.role_id IS 'Foreign key referencing the roles table (role id)';


--
-- Name: COLUMN user_roles.date_created; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_roles.date_created IS 'Timestamp of creation';


--
-- Name: COLUMN user_roles.date_updated; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_roles.date_updated IS 'Timestamp of last update';


--
-- Name: COLUMN user_roles.date_deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_roles.date_deleted IS 'Timestamp of deletion';


--
-- Name: COLUMN user_roles.is_deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_roles.is_deleted IS 'Flag indicating if the record is deleted (1) or not (0)';


--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_id_seq OWNER TO postgres;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying(36) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    verified integer DEFAULT 0 NOT NULL,
    social_type integer DEFAULT 0 NOT NULL,
    last_login_date timestamp with time zone,
    disabled_by character varying,
    deleted_by character varying,
    disabled integer DEFAULT 0 NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    time_zone character varying DEFAULT 'UTC'::character varying NOT NULL,
    date_created timestamp with time zone NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    date_deleted timestamp with time zone,
    is_deleted integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: COLUMN users.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.id IS 'uuid';


--
-- Name: COLUMN users.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.email IS 'The email address of user';


--
-- Name: COLUMN users.password; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.password IS 'Encrypted password';


--
-- Name: COLUMN users.verified; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.verified IS 'The flag represend email verification. 1: verified, 0: other case.';


--
-- Name: COLUMN users.social_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.social_type IS '0: none socail user.
1: from google';


--
-- Name: COLUMN users.last_login_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.last_login_date IS 'The timestamp represent the last login date.';


--
-- Name: COLUMN users.disabled_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.disabled_by IS 'uuid of the user who disabled this user';


--
-- Name: COLUMN users.deleted_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.deleted_by IS 'uuid of the user who deleted this user';


--
-- Name: COLUMN users.disabled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.disabled IS 'Indicates whether this user is disabled(1) or not(0).';


--
-- Name: COLUMN users.first_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.first_name IS 'The first name of this user';


--
-- Name: COLUMN users.last_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.last_name IS 'The last name of this user.';


--
-- Name: COLUMN users.time_zone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.time_zone IS 'The timezone of this user';


--
-- Name: COLUMN users.is_deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.is_deleted IS 'Represent whether this user was deleted(1) or not(0)';


--
-- Name: verification_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_token (
    id character varying(36) NOT NULL,
    expiry_date timestamp with time zone NOT NULL,
    user_id character varying NOT NULL,
    date_created timestamp with time zone NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    date_deleted timestamp with time zone,
    is_deleted integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.verification_token OWNER TO postgres;

--
-- Name: COLUMN verification_token.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.verification_token.id IS 'uuid';


--
-- Name: COLUMN verification_token.expiry_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.verification_token.expiry_date IS 'The token expiration date and time';


--
-- Name: COLUMN verification_token.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.verification_token.user_id IS 'Id of users table.';


--
-- Name: COLUMN verification_token.is_deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.verification_token.is_deleted IS 'Represent whether this user was deleted(1) or not(0)';


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, date_created, date_updated, date_deleted, is_deleted) FROM stdin;
\.
COPY public.roles (id, name, date_created, date_updated, date_deleted, is_deleted) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (id, user_id, role_id, date_created, date_updated, date_deleted, is_deleted) FROM stdin;
\.
COPY public.user_roles (id, user_id, role_id, date_created, date_updated, date_deleted, is_deleted) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, verified, social_type, last_login_date, disabled_by, deleted_by, disabled, first_name, last_name, time_zone, date_created, date_updated, date_deleted, is_deleted) FROM stdin;
\.
COPY public.users (id, email, password, verified, social_type, last_login_date, disabled_by, deleted_by, disabled, first_name, last_name, time_zone, date_created, date_updated, date_deleted, is_deleted) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: verification_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_token (id, expiry_date, user_id, date_created, date_updated, date_deleted, is_deleted) FROM stdin;
\.
COPY public.verification_token (id, expiry_date, user_id, date_created, date_updated, date_deleted, is_deleted) FROM '$$PATH$$/3341.dat';

--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 2, true);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 5, true);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_token verification_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_token
    ADD CONSTRAINT verification_token_pkey PRIMARY KEY (id);


--
-- Name: user_roles fk_user_role_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fk_user_role_role FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles fk_user_role_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fk_user_role_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: verification_token fk_user_token; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_token
    ADD CONSTRAINT fk_user_token FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

